# What have I done in this project?

- Rename, remake all warriors, armors, weapon
- Add special ability to each class of warrior


# Knowledge applied:
- Use array to create armor, weapon for a cleaner code
- Create a setup file in utils for creating warrior, armor, weapon instead of putting in Battle.java. Just simply call the function in the battle when setting up the game
- use printf for formatting printing options with arguments for easier when change the number later. For that reason, I have to remove abstract in Armor and Weapon class
- Combine for loop and printf to shorten the print function in Printer.java