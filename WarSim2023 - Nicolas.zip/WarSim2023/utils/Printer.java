package utils;
import warrior.*;
import armor.*;
import weapon.*;

public class Printer {
    public Armor armor = new Armor();
    public Weapon weapon = new Weapon();
    public String[] listCharacter = {"Knight", "Priest", "Assasin", "Archer", "Barbarian", "Witcher"};

    public Printer() {

    }


    public void welcome() {
        System.out.println("Welcome to WarSim 2023 - by Nicolas Pham");
    }

    public void characterOptions() {
        System.out.println("Which race would you like to play?");
        System.out.println("1) Human with Knight and Priest");
        System.out.println("2) Elf with Assasin and Archer");
        System.out.println("3) Orc with Barbarian and Witcher");
    }
/********************   Character Options  ********************************/ 
    public void humanOptions() {

        System.out.println("1) Knight - strong, medium damage but slow");
        System.out.println("2) Priest - medium strength and damage but fast like Elf");
    }
    public void elfOptions() {
        System.out.println("1) Assasin - huge damage, very fast but low health");
        System.out.println("2) Archer - the fastest class with big damage, low health");
    }
    public void orcOptions() {
        System.out.println("1) Barbarian: has the strongest health with big damage, very slow");
        System.out.println("2) Witcher - medium damage, big health but just faster than Barbarian");
    }
/********************   Stats Selection ********************************/ 
    public void intialStats(int characterChoice, int armorChoice, int weaponChoice, Warrior warrior, Armor armor, Weapon weapon) {
        int totalDefend = warrior.getDefend() + armor.getArmor()[0] + weapon.getWeapon()[2];
        int totalDamage = warrior.getDamage() + weapon.getWeapon()[0];
        int totalSpeed = warrior.getSpeed() + armor.getArmor()[1] + weapon.getWeapon()[1];

        System.out.printf("Selection: \t%s, %s, %s\n", listCharacter[characterChoice], armor.listArmor[armorChoice], weapon.listWeapon[weaponChoice]);
        System.out.println("Health: \t" + warrior.getHealth());
        System.out.printf("Defend: \t%d + %d + %d = %d\n", warrior.getDefend(), armor.getArmor()[0], weapon.getWeapon()[2], totalDefend);
        System.out.printf("Damage: \t%d + %d = %d\n",warrior.getDamage(), weapon.getWeapon()[0], totalDamage);
        System.out.println("Staminia:\t" + warrior.getStaminia());
        System.out.printf("Speed / Dex: \t%d + %d + %d = %d\n", warrior.getSpeed(), armor.getArmor()[1], weapon.getWeapon()[1], totalSpeed);
        System.out.println("Skill: \t" + warrior.getAbility());
    }

    public void currentStats(Warrior warrior) {
        System.out.println("Health: \t" + warrior.getHealth());
        System.out.println("Defend: \t" + warrior.getDefend());
        System.out.println("Damage: \t" + warrior.getDamage());
        System.out.println("Staminia:\t" + warrior.getStaminia());
        System.out.println("Speed / Dex: \t" + warrior.getSpeed());
        System.out.println("Spec.ab: \t" + warrior.getAbility());
    }

/******************** Armor Selection ********************************/ 
    public void armorSelection() {
        System.out.println("What type of armor wdo you want?");
        for (int i=0; i < armor.listArmor.length; i++) {
            System.out.printf("%d) Leather: \t%d defend, %d speed\n",i+1, armor.defend[i], armor.speed[i]);
        }
    }
/******************** Weapon Selection ********************************/ 
    public void weaponSelection() {
        System.out.println("Which weapon would you like to play?");
        for (int i=0; i < weapon.listWeapon.length; i++)
        System.out.printf("%d) %s: \t%d damage, %d speed, %d defend\n", i+1, weapon.listWeapon[i], weapon.damage[i], weapon.speed[i], weapon.defend[i]);
    }

}
