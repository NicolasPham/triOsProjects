# Points Count:
- Easy:
    > 1 point: add another child to the warrior
    > 1 point: prompt the user for a name for their warrior and a name for enemy
    > 1 point: add validation for all inputs
    > 1 point: add color to the output in the terminal
    > 1 point: give the player ability to surrender
    > 1 point: track the number of turns, damages, print after match

- Medium:
    > 3 points: add magic attack (special skill depends on each Warrior type)
    > 3 points: provide a way for resetting game without restarting from the begining
    > 3 points: add a description class to provide some color commentary for the battle
    > 3 points: add another stat to warrior - luck will be added randomly when the warrior perform the attack

- Hard:
    > 5 points: Create a polymorphic special ability based on the warrior class (use staminia to cast skill)
    > 7 points: Subtype children from the warrior (Human has Knight and Priest, Elf has Assasin and Archer, Orc has Barbarian and Witcher)

- Advance:
    > Rewrite the application. Use both composition and inheritance