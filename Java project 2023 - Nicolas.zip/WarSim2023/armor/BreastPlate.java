package armor;

public class BreastPlate extends Armor {
    private int[] armor = {defend[2], speed[2]};

    public BreastPlate() {
        super();
        super.setArmor(armor);
    }
}
